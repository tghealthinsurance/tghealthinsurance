THE THOMPSON GROUP — LAUNCH PACKAGE
Domain: tghealthinsurance.com
GitHub: tghealthinsurance/tghealthinsurance

UPLOAD
1. Open the GitHub repository.
2. Delete/replace the old site files if needed.
3. Upload every file and the assets folder from this package to the repository root.
4. Commit the changes to the main branch.

GITHUB PAGES
Settings > Pages > Deploy from a branch > main > /(root) > Save.
The included CNAME file sets tghealthinsurance.com as the custom domain.

FORM
The quote form is connected to Basin endpoint:
https://usebasin.com/f/d9cef9247be9
Test the form immediately after launch and confirm the submission appears in Basin and reaches the destination inbox.

EMAIL
Public email: quotes@tghealthinsurance.com
Confirm Cloudflare Email Routing is active and test it by sending an email from a separate address.

BEFORE ADVERTISING
Review privacy, consent, disclosures and marketing claims with your agency/compliance resources. Privacy and terms pages are general templates, not legal advice.
