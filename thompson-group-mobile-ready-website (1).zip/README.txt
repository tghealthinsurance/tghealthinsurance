THOMPSON GROUP — MOBILE-READY WEBSITE

Open index.html to preview.

Responsive features:
- Mobile menu
- Stacked phone-friendly quote form
- Touch-friendly buttons
- Sticky Call Now / Get a Quote mobile bar
- Responsive typography, images and cards
- Scalable actual U.S. state map
- Tablet and phone breakpoints
- Safe-area support for modern phones

The U.S. map loads state boundary data from jsDelivr, so the map requires an
internet connection. The rest of the website and local images load from this package.

Form submissions:
garrett.thompson@ushadvisors.com via FormSubmit.
The first submission may require email activation.

Before publishing, have your compliance/legal team review the form, health-data
collection, privacy policy, consent language and data-handling process.
